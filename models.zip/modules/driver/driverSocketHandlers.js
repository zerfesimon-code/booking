module.exports = function registerDriverSocketHandlers(io, socket) {
  // Intentionally empty for now. Driver events are handled in `sockets/driverSocket.js`.
};

