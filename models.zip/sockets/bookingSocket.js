const bookingService = require('../services/bookingService');
const bookingEvents = require('../events/bookingEvents');
const { sendMessageToSocketId } = require('./utils');
const lifecycle = require('../services/bookingLifecycleService');
const logger = require('../utils/logger');
const { Booking } = require('../models/bookingModels');

module.exports = (io, socket) => {
  // booking_request (create booking)
  socket.on('booking_request', async (payload) => {
    logger.info('[booking_request] received', { socketId: socket.id, payload });
    try {
      const data = typeof payload === 'string' ? JSON.parse(payload) : (payload || {});
      if (!socket.user || String(socket.user.type).toLowerCase() !== 'passenger') {
        logger.warn('[booking_request] unauthorized attempt', { socketId: socket.id });
        return socket.emit('booking_error', { message: 'Unauthorized: passenger token required' });
      }
      const passengerId = String(socket.user.id);
      const booking = await bookingService.createBooking({
        passengerId,
        jwtUser: socket.user,
        vehicleType: data.vehicleType || 'mini',
        pickup: data.pickup,
        dropoff: data.dropoff,
        authHeader: socket.authToken ? { Authorization: socket.authToken } : undefined
      });
      const bookingRoom = `booking:${String(booking._id)}`;
      socket.join(bookingRoom);
      socket.emit('booking:created', { bookingId: String(booking._id) });
      logger.info('[booking_request] booking created', { bookingId: booking._id, passengerId });

      // Broadcast to nearby drivers
      try {
        const { driverByLocationAndVehicleType } = require('../services/nearbyDrivers');
        const nearest = await driverByLocationAndVehicleType({
          latitude: booking.pickup.latitude,
          longitude: booking.pickup.longitude,
          vehicleType: booking.vehicleType,
          radiusKm: parseFloat(process.env.BROADCAST_RADIUS_KM || '100'),
          limit: 5
        });
        logger.info('the nearest drivers are', { nearest });
        const targets = (nearest || []).map(x => x.driver);
        const patch = {
          bookingId: String(booking._id),
          patch: {
            status: 'requested',
            passengerId,
            vehicleType: booking.vehicleType,
            pickup: booking.pickup,
            dropoff: booking.dropoff,
            passenger: { id: passengerId, name: socket.user.name, phone: socket.user.phone }
          }
        };
        logger.info('the targets are', { targets });
        targets.forEach(d => {
          sendMessageToSocketId(`driver:${String(d._id)}`, { event: 'booking:new', data: patch });
          try{
            sendMessageToSocketId(`driver:${String(d._id)}`, { event: 'booking:nearby', data: patch });
        logger.info('[booking_request] broadcast sent to driver', { bookingId: booking._id, driverId: String(d._id) });}
        catch(_){
          logger.error('[booking_request] broadcast sent to driver failed', { bookingId: booking._id, driverId: String(d._id) });
        }
        });
        logger.info('[booking_request] broadcast sent to drivers', { bookingId: booking._id, drivers: targets.map(d => d._id), events: ['booking:new','booking:nearby'] });
      } catch (err) {
        logger.error('[booking_request] nearby drivers broadcast failed', err);
      }
    } catch (err) {
      logger.error('[booking_request] error creating booking', err);
      socket.emit('booking_error', { message: 'Failed to create booking' });
    }
  });

  // booking_accept
  socket.on('booking_accept', async (payload) => {
    logger.info('[booking_accept] received', { socketId: socket.id, payload });
    try {
      const data = typeof payload === 'string' ? JSON.parse(payload) : (payload || {});
      const bookingId = String(data.bookingId || '');
      if (!socket.user || String(socket.user.type).toLowerCase() !== 'driver' || !socket.user.id) {
        logger.warn('[booking_accept] unauthorized attempt', { socketId: socket.id });
        return socket.emit('booking_error', { message: 'Unauthorized: driver token required', bookingId });
      }
      if (!bookingId) return socket.emit('booking_error', { message: 'bookingId is required' });

      const updated = await bookingService.updateBookingLifecycle({ requester: socket.user, id: bookingId, status: 'accepted' });
      const room = `booking:${String(updated._id)}`;
      socket.join(room);
      bookingEvents.emitBookingUpdate(String(updated._id), { status: 'accepted', driverId: String(socket.user.id), acceptedAt: updated.acceptedAt });
      // Broadcast assignment for listeners relying on this signal
      try { bookingEvents.emitBookingAssigned(String(updated._id), String(socket.user.id)); } catch (_) {}
      // Targeted message to the accepting driver so the booking stays/updates in their list
      try {
        sendMessageToSocketId(`driver:${String(socket.user.id)}`, {
          event: 'booking:accepted',
          data: {
            bookingId: String(updated._id),
            patch: { status: 'accepted', driverId: String(socket.user.id), acceptedAt: updated.acceptedAt }
          }
        });
      } catch (_) {}
      logger.info('[booking_accept] booking accepted', { bookingId, driverId: socket.user.id });

      // Inform nearby drivers to remove booking
      try {
        const { Driver } = require('../models/userModels');
        const geolib = require('geolib');
        const drivers = await Driver.find({ available: true }).lean();
        const radiusKm = parseFloat(process.env.RADIUS_KM || process.env.BROADCAST_RADIUS_KM || '100');
        const vehicleType = updated.vehicleType;
        const nearby = drivers.filter(d => (
          d && d._id && String(d._id) !== String(socket.user.id) &&
          d.lastKnownLocation &&
          (!vehicleType || String(d.vehicleType || '').toLowerCase() === String(vehicleType || '').toLowerCase()) &&
          (geolib.getDistance(
            { latitude: d.lastKnownLocation.latitude, longitude: d.lastKnownLocation.longitude },
            { latitude: updated.pickup?.latitude, longitude: updated.pickup?.longitude }
          ) / 1000) <= radiusKm
        ));
        nearby.forEach(d => sendMessageToSocketId(`driver:${String(d._id)}`, { event: 'booking:removed', data: { bookingId: String(updated._id) } }));
        logger.info('[booking_accept] removed booking from nearby drivers', { bookingId, removedDrivers: nearby.map(d => d._id) });
      } catch (err) {
        logger.error('[booking_accept] error notifying nearby drivers', err);
      }
    } catch (err) {
      logger.error('[booking_accept] error', err);
    }
  });

  // booking_cancel
  socket.on('booking_cancel', async (payload) => {
    logger.info('[booking_cancel] received', { socketId: socket.id, payload });
    try {
      const data = typeof payload === 'string' ? JSON.parse(payload) : (payload || {});
      const bookingId = String(data.bookingId || '');
      const reason = data.reason;
      if (!socket.user || !socket.user.type) {
        logger.warn('[booking_cancel] unauthorized attempt', { socketId: socket.id });
        return socket.emit('booking_error', { message: 'Unauthorized: user token required', bookingId });
      }
      if (!bookingId) return socket.emit('booking_error', { message: 'bookingId is required', bookingId });
      const updated = await bookingService.updateBookingLifecycle({ requester: socket.user, id: bookingId, status: 'canceled' });
      bookingEvents.emitBookingUpdate(String(updated._id), { status: 'canceled', canceledBy: String(socket.user.type).toLowerCase(), canceledReason: reason });
      logger.info('[booking_cancel] booking canceled', { bookingId, canceledBy: socket.user.type, reason });
    } catch (err) {
      logger.error('[booking_cancel] error', err);
    }
  });

  // trip_started
  socket.on('trip_started', async (payload) => {
    logger.info('[trip_started] received', { socketId: socket.id, payload });
    try {
      const data = typeof payload === 'string' ? JSON.parse(payload) : (payload || {});
      const bookingId = String(data.bookingId || '');
      const startLocation = data.startLocation || data.location;
      if (!socket.user || String(socket.user.type).toLowerCase() !== 'driver') {
        logger.warn('[trip_started] unauthorized attempt', { socketId: socket.id });
        return socket.emit('booking_error', { message: 'Unauthorized: driver token required', source: 'trip_started' });
      }
      if (!bookingId) return socket.emit('booking_error', { message: 'bookingId is required', source: 'trip_started' });
      const booking = await Booking.findOne({ _id: bookingId, driverId: String(socket.user.id) });
      if (!booking) {
        logger.warn('[trip_started] booking not found', { bookingId, driverId: socket.user.id });
        return socket.emit('booking_error', { message: 'Booking not found or not assigned to you', source: 'trip_started' });
      }
      const updated = await lifecycle.startTrip(bookingId, startLocation);
      bookingEvents.emitTripStarted(io, updated);
      logger.info('[trip_started] trip started', { bookingId, driverId: socket.user.id });
    } catch (err) {
      logger.error('[trip_started] error', err);
      socket.emit('booking_error', { message: 'Failed to start trip', source: 'trip_started' });
    }
  });

  // trip_ongoing
  socket.on('trip_ongoing', async (payload) => {
    logger.info('[trip_ongoing] received', { socketId: socket.id, payload });
    try {
      const data = typeof payload === 'string' ? JSON.parse(payload) : (payload || {});
      const bookingId = String(data.bookingId || '');
      const location = data.location || { latitude: data.latitude, longitude: data.longitude };
      if (!socket.user || String(socket.user.type).toLowerCase() !== 'driver') {
        logger.warn('[trip_ongoing] unauthorized attempt', { socketId: socket.id });
        return socket.emit('booking_error', { message: 'Unauthorized: driver token required', source: 'trip_ongoing' });
      }
      if (!bookingId || !location || location.latitude == null || location.longitude == null) {
        return socket.emit('booking_error', { message: 'bookingId and location are required', source: 'trip_ongoing' });
      }
      const booking = await Booking.findOne({ _id: bookingId, driverId: String(socket.user.id) }).lean();
      if (!booking) {
        logger.warn('[trip_ongoing] booking not found', { bookingId, driverId: socket.user.id });
        return socket.emit('booking_error', { message: 'Booking not found or not assigned to you', source: 'trip_ongoing' });
      }
      const point = await lifecycle.updateTripLocation(bookingId, String(socket.user.id), location);
      bookingEvents.emitTripOngoing(io, bookingId, point);
      logger.info('[trip_ongoing] location updated', { bookingId, driverId: socket.user.id, location });
    } catch (err) {
      logger.error('[trip_ongoing] error', err);
      socket.emit('booking_error', { message: 'Failed to update trip location', source: 'trip_ongoing' });
    }
  });

  // trip_completed
  socket.on('trip_completed', async (payload) => {
    logger.info('[trip_completed] received', { socketId: socket.id, payload });
    try {
      const data = typeof payload === 'string' ? JSON.parse(payload) : (payload || {});
      const bookingId = String(data.bookingId || '');
      const endLocation = data.endLocation || data.location;
      const surgeMultiplier = data.surgeMultiplier || 1;
      const discount = data.discount || 0;
      const debitPassengerWallet = !!data.debitPassengerWallet;
      if (!socket.user || String(socket.user.type).toLowerCase() !== 'driver') {
        logger.warn('[trip_completed] unauthorized attempt', { socketId: socket.id });
        return socket.emit('booking_error', { message: 'Unauthorized: driver token required', source: 'trip_completed' });
      }
      if (!bookingId) return socket.emit('booking_error', { message: 'bookingId is required', source: 'trip_completed' });
      const booking = await Booking.findOne({ _id: bookingId, driverId: String(socket.user.id) });
      if (!booking) {
        logger.warn('[trip_completed] booking not found', { bookingId, driverId: socket.user.id });
        return socket.emit('booking_error', { message: 'Booking not found or not assigned to you', source: 'trip_completed' });
      }
      const updated = await lifecycle.completeTrip(bookingId, endLocation, { surgeMultiplier, discount, debitPassengerWallet });
      bookingEvents.emitTripCompleted(io, updated);
      logger.info('[trip_completed] trip completed', { bookingId, driverId: socket.user.id, endLocation });
    } catch (err) {
      logger.error('[trip_completed] error', err);
      socket.emit('booking_error', { message: 'Failed to complete trip', source: 'trip_completed' });
    }
  });
};
